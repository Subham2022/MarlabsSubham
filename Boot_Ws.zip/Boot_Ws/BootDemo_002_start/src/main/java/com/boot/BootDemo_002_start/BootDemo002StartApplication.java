package com.boot.BootDemo_002_start;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootDemo002StartApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootDemo002StartApplication.class, args);
	}

}
