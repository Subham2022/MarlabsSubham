package com.boot.BootDemo_002_start;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
	@RequestMapping(value="/")
	public String hello()
	{
		return "This is Start output";
	}

}
