package com.boot.BootDemo_002_start;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootDemo002StartApplicationTests {

	@Test
	void contextLoads() {
	}

}
