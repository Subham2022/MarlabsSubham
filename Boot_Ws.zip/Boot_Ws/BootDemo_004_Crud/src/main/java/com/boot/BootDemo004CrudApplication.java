package com.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootDemo004CrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootDemo004CrudApplication.class, args);
	}
	
}
