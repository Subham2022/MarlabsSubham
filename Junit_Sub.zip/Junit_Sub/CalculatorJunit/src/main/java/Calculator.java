
public class Calculator {


	public int square(int i)
	{
		return i*i;
	}
	public String user(String string)
	{
		return "Shubham";
	}
	public int sub(int i,int j)
	{
		return i-j;
	}
	public int add(int i,int j)
	{
		return i+j;
	}
	public String concat(String string1,String string2)
	{
		return string1+string2;
	}
}

