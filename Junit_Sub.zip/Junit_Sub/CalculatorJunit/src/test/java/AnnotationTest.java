import static org.junit.Assert.*;
import org.junit.*;
public class AnnotationTest {

	@BeforeClass
	public static void beforeClass() throws Exception
	{
		System.out.println("First Before any Execution");
	}
	@Before
	public void beforeMethod() throws Exception
	{
		System.out.println("Before each Test Execution");
	}
	@Test
	public void testCube()
	{
		assertEquals(27,Test2Demo.cube(3));
	}

	
	
	  @Test public void reverseWord() {
	  System.out.println(Test2Demo.reverseWord("my name is khan"));
	  assertEquals("ym eman si nahk ",Test2Demo.reverseWord("my name is khan")); }
	 
	 
	@After
	public  void afterMethod() throws Exception
	{
		System.out.println("After each Test Execution");
	}
	@AfterClass
	public static void afterClass() throws Exception
	{
		System.out.println("Finally After All Execution");
	}
	
}