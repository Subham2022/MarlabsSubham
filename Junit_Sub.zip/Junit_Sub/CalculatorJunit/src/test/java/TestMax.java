import static org.junit.Assert.*;
import org.junit.Test;

public class TestMax 
{
@Test
public void testMax()
{
	assertEquals(14,MaxNumber.findMax(new int[] {1,2,3,14}));
	assertEquals(24,MaxNumber.findMax(new int[] {1,2,3,14,24}));
	
}
}