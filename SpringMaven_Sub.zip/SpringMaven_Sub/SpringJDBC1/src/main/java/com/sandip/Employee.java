//create table employee(id number,name varchar2(30),salary number(8,2));
package com.sandip;
public class Employee 
{
private int id;
private String name;
private float salary;
private String dept;
private String desig;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public float getSalary() {
	return salary;
}
public void setSalary(float salary) {
	this.salary = salary;
}
public String getDept() {
	return dept;
}
public void setDept(String dept) {
	this.dept = dept;
}
public String getDesig() {
	return desig;
}
public void setDesig(String desig) {
	this.desig = desig;
}
public Employee(int id, String name, float salary, String dept, String desig) {
	super();
	this.id = id;
	this.name = name;
	this.salary = salary;
	this.dept = dept;
	this.desig = desig;
}
public Employee() {
	
}



}
