package com.subham;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");
		Scanner ob=new Scanner(System.in);
		System.out.println("Enter choice: 1: To insert the data. 2: To update data. 3: To delete data. 4: To get all the data. 5: To get data by rollNo");
		int choice=ob.nextInt();
		switch(choice)
		{
		case 1:
		{
			System.out.println("Enter rollno, Name, Address");
			int rollno=ob.nextInt();
			String name=ob.next();
			String address=ob.next();
			StudentDao dao=(StudentDao)ctx.getBean("sdao");
			boolean status=dao.saveStudent(new Student(rollno, name, address));
			if(status==false)
			{
				System.out.println("Student Data inserted");
				break;
			}
		}
		case 2:
		{
			System.out.println("Enter the rollno name address to update the data");
			int rollno=ob.nextInt();
			String name=ob.next();
			String address=ob.next();
			StudentDao dao=(StudentDao)ctx.getBean("sdao");
			boolean status=dao.updateStudent(new Student(rollno, name, address));
			if (status==false)
			{
				System.out.println("Student data updated");
				break;
			}
		}
		case 3:
		{
			System.out.println("Enter the student rollno you want to delete");
			int rollno=ob.nextInt();
			StudentDao dao=(StudentDao)ctx.getBean("sdao");
			Student s=new Student();
			s.setRollno(rollno);
			boolean status=dao.deleteStudent(s);
			if (status==false)
			{
				System.out.println("Student data deleted");
				break;
			}
		}
		case 4:
		{
			StudentDao dao=(StudentDao)ctx.getBean("sdao");
			List<Student> list=dao.getAllStudent();
			for(Student s:list)
			{
				System.out.println(s);
			}
			break;
			
		}
		case 5:
		{
			System.out.println("Enter roll no to search");
			StudentDao dao=(StudentDao)ctx.getBean("sdao");
			int roll=ob.nextInt();
			Student s=new Student();
			s.setRollno(roll);
			Student s1=dao.searchByRollno(s);
			System.out.println(s1);
			break;
		}
		}

	}

}
