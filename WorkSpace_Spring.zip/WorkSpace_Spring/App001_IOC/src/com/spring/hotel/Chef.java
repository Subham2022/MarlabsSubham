package com.spring.hotel;

public interface Chef {
	public String prepareFood();

}
