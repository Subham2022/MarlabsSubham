package com.spring.hotel;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class HotelManagement {

	public static void main(String[] args) {
		// Load the configure file
		
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("Spring.xml");
		
		
		//Retrive the bean from Spring Container
		Chef chef=ctx.getBean("iChef",Chef.class);
		
		
		
		
		//call the method
		System.out.println(chef.prepareFood());
		
		
		
		// Close the context
		ctx.close();
	}

}
