package com.spring.hotel;

public class IndianChef  implements Chef {

	@Override
	public String prepareFood() {
		
		return "Tanduri Chicken";
	}

}
