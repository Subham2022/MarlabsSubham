package com.spring;

public class Car {
	private Tyre t;
	private String brand;
	private String model;
	
	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public void setT(Tyre t) {
		this.t = t;
	}

	void letsgo()
	{
		System.out.println("We are going to bangalore");
		System.out.println(t.move());
	}



}
