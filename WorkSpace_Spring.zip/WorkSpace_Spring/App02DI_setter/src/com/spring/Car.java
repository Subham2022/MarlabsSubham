package com.spring;

public class Car {
	
	private Tyre t;
	
	public void setT(Tyre t) {
		this.t = t;
	}

	void letsgo()
	{
		System.out.println("We are going to bangalore");
		System.out.println(t.move());
	}

}
