package com.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Drive {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("spring.xml");
		
		Car car=ctx.getBean("myCar",Car.class);
		
		car.letsgo();
		
		ctx.close();

	}

}
