package com.spring;

public class Tyre {
	public String move()
	{
		return "moving with speed of 80km/hr";
	}

}
