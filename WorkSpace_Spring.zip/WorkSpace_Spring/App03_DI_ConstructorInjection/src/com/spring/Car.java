package com.spring;

public class Car {
private Tyre t;
	
	
	public Car(Tyre t) {
	super();
	this.t = t;
}


	void letsgo()
	{
		System.out.println("We are going to bangalore");
		System.out.println(t.move());
	}

}
