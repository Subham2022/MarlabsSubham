package com.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Drive {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("spring.xml");
		
		Car car=ctx.getBean("myCar",Car.class);
		System.out.println(car.getBrand());
		System.out.println(car.getModel());
		
		car.letsgo();
		
		ctx.close();


	}

}
