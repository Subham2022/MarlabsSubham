package com.spring;

public class TestBeanLifeCycle {

	public TestBeanLifeCycle() {
		super();
		System.out.println("TestBean-Constructor");
	}
	
	
	public void myInitMethod()
	{
		System.out.println("TestBean-InitMethod");
	}
	public void myDestroyMethod()
	{
		System.out.println("TestBean-DestroyMethod");
	}
	

}
