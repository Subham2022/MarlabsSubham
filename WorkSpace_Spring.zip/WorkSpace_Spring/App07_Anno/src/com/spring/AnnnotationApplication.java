package com.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AnnnotationApplication {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("AnnoApplication.xml");
		Eagle e=ctx.getBean("eagle",Eagle.class);
		e.fly();
		
		ctx.close();

	}

}
