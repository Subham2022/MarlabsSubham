package com.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringApplication {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("AnnoApplication.xml");
		
		TestBean tbean=ctx.getBean("testBean",TestBean.class);
		
		ctx.close();

	}

}
