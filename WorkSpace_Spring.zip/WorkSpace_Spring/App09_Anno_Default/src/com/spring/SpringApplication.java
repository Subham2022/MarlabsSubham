package com.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringApplication {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("AnnoApplication.xml");
		TBean tbean=ctx.getBean("TBean",TBean.class);
		
		ctx.close();

	}

}
