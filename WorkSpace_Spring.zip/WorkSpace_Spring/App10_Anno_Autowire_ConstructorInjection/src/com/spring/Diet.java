package com.spring;

public interface Diet {
	public void eat();
}
