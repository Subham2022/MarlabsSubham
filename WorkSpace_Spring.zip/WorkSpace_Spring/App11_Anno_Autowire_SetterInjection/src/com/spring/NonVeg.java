package com.spring;

import org.springframework.stereotype.Component;

@Component
public class NonVeg implements Diet {

	@Override
	public void eat() {
		System.out.println("red & Juicy Meat");
		
	}
	

}
