package om.spring;

public interface Bird {
	public void eatingStyle();

}
