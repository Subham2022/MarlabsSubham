package om.spring;

public interface Diet {
	public void eat();
}
