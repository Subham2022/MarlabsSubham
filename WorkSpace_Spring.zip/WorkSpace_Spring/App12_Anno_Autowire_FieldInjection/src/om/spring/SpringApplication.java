package om.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringApplication {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("AnnoApplication.xml");
		
		Bird bird=ctx.getBean("vulture",Bird.class);
		bird.eatingStyle();
		ctx.close();

	}

}
