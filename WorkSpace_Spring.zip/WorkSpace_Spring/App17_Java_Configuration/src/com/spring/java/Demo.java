package com.spring.java;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spring.configuration.SpringConfiguration;

public class Demo {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx=new AnnotationConfigApplicationContext(SpringConfiguration.class);
		
		MyBean mb=ctx.getBean("myBean",MyBean.class);
		mb.test();
		ctx.close();

	}

}
